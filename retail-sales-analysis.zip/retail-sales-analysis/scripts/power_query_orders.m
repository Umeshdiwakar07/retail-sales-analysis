// Power BI: Home > Get Data > Blank Query > Advanced Editor > paste this.
// Change the file path to where you saved superstore_clean.csv. Name the query: Orders
let
    Source = Csv.Document(File.Contents("C:\path\to\data\superstore_clean.csv"),
                [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Headers = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    Typed = Table.TransformColumnTypes(Headers, {
        {"Row ID", Int64.Type}, {"Order ID", type text}, {"Order Date", type date}, {"Ship Date", type date},
        {"Ship Mode", type text}, {"Customer ID", type text}, {"Customer Name", type text}, {"Segment", type text},
        {"Country", type text}, {"State", type text}, {"Region", type text}, {"Product ID", type text},
        {"Category", type text}, {"Sub-Category", type text}, {"Product Name", type text},
        {"Sales", type number}, {"Quantity", Int64.Type}, {"Discount", type number}, {"Profit", type number},
        {"Year", Int64.Type}, {"Month Number", Int64.Type}, {"Month Name", type text}, {"Quarter", type text},
        {"Ship Days", Int64.Type}, {"Profit Margin", type number}, {"Discount Band", type text}
    }, "en-US"),
    NoDupes = Table.Distinct(Typed, {"Row ID"}),
    NoErrors = Table.RemoveRowsWithErrors(NoDupes)
in
    NoErrors
