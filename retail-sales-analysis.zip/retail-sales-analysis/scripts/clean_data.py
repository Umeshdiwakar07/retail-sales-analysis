"""Clean data/superstore_sales.csv -> data/superstore_clean.csv. Run from repo root: python scripts/clean_data.py"""
import pandas as pd
import numpy as np

df = pd.read_csv("data/superstore_sales.csv")
print("Raw shape:", df.shape)

# 1. Duplicates
df = df.drop_duplicates().reset_index(drop=True)

# 2. Dates
df["Order Date"] = pd.to_datetime(df["Order Date"], format="%d-%m-%Y")
df["Ship Date"] = pd.to_datetime(df["Ship Date"], format="%d-%m-%Y")

# 3. Text standardisation
for col in ["Segment", "Region", "State", "Category", "Sub-Category", "Ship Mode", "Customer Name"]:
    df[col] = df[col].astype("string").str.strip()
df["Segment"] = df["Segment"].str.title()
df["Region"] = df["Region"].str.title()

# 4. Missing values
df["State"] = df["State"].fillna("Unknown")
df = df.dropna(subset=["Sales", "Profit", "Order Date"])

# 5. New columns
df["Year"] = df["Order Date"].dt.year
df["Month Number"] = df["Order Date"].dt.month
df["Month Name"] = df["Order Date"].dt.strftime("%b")
df["Quarter"] = "Q" + df["Order Date"].dt.quarter.astype(str)
df["Ship Days"] = (df["Ship Date"] - df["Order Date"]).dt.days
df["Profit Margin"] = np.where(df["Sales"] != 0, df["Profit"] / df["Sales"], 0).round(4)
df["Discount Band"] = pd.cut(
    df["Discount"], bins=[-0.01, 0, 0.10, 0.20, 0.30, 1],
    labels=["0%", "1-10%", "11-20%", "21-30%", "31%+"]).astype(str)

# 6. Quick EDA
print(df[["Sales", "Quantity", "Discount", "Profit"]].describe())
print("Correlation:\n", df[["Sales", "Discount", "Profit"]].corr().round(2))
q1, q3 = df["Profit"].quantile([.25, .75]); iqr = q3 - q1
print("Profit outliers:", ((df["Profit"] < q1 - 1.5*iqr) | (df["Profit"] > q3 + 1.5*iqr)).sum())

df.to_csv("data/superstore_clean.csv", index=False)
print("Clean shape:", df.shape, "-> saved data/superstore_clean.csv")
