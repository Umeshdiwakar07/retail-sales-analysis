# Retail Sales Dashboard | AI and Data Analysis Project

An AI-assisted data analysis project on synthetic retail data: about 10,000 order lines (2022 to 2025) cleaned in Python and presented in an interactive 4-page dashboard on sales, profit, discounts and customers.

> **AI note:** This project was built with help from Claude (an AI assistant), which generated the synthetic dataset, starter code and the dashboard. I worked through each step to understand it.
>
> **Data note:** The dataset is **synthetic**, built to mimic the structure of the Superstore sales dataset. It is not real company data, so the focus is on the method.

![Executive Overview](screenshots/overview.png)

## Live dashboard
Open `docs/index.html` in a browser (internet needed for the charts). To host it free: Settings > Pages > Deploy from a branch > `main` / `/docs`.

## Business questions
1. How are sales and profit trending?
2. Which products and regions are most and least profitable?
3. How do discounts affect profit?
4. Who are the top customers?
5. Are there seasonal patterns?

## Key results
- Total sales **$4,877,496**, profit **$681,627**, margin **14.0%**
- Sales grew from $834,266 (2022) to $1,485,435 (2025), **+78.1%**
- 4,021 orders, 797 customers, average order value $1,213
- Order lines discounted **above 30%** lose money overall; recommendation: cap discounts at 20% (test before rollout)
- December is the strongest month; Furniture has large sales but close to zero profit

## Dashboard pages
Executive Overview | Products and Profitability | Discount Impact | Customers and Seasonality. Filters: Year, Region, Segment, Category.

## Repository structure
```
data/         superstore_sales.csv (raw), superstore_clean.csv (cleaned)
scripts/      clean_data.py, power_query_orders.m
powerbi/      dax_measures.dax, retail_theme.json (files for a Power BI version)
docs/         index.html (interactive dashboard)
screenshots/  overview.png
```

## How to reproduce
```
pip install pandas numpy
python scripts/clean_data.py
```
Removes duplicates, fixes dates and text, fills missing states, and adds Year, Month, Ship Days, Profit Margin and Discount Band columns.

## Tools
Python (Pandas), HTML and Chart.js for the dashboard. DAX and Power Query files are included for building a Power BI version.

## Author
**Your Name** | [LinkedIn](https://www.linkedin.com/in/your-profile)
